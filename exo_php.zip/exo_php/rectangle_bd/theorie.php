<?php
//Base Données
  /*
  Acces au donnees d'une Base de Données
       1)Connexion  à la Base=>chaine de Connexion
          a)@server de la machine qui herberge le SGBD:localhost
          b)utlisateur du SGBD : Mysql => root
          c)Mot de passe  utlisateur :=> ""
      2)  Ecriture et Execution des Requetes=> LMD(insert,update,delete,select) 
          a)Mise à Jour , change l'etat de BD => insert ,update, delete  =>  reourne un entier(nbre ligne qui a été Modifiée)
          b)Interogation, recuperer des Données=> select => Tableau des Données

      3)  Recuperation des Résultats 

      4) Fermer la Connexion
               

          
  */

?>